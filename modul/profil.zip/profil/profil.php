<?php
if (!defined('cms-KONTEN')) {
    Header("Location: ../index.php");
    exit;
}

global $koneksi_db, $tengah;

// Tarik data profil dari database
$res = $koneksi_db->sql_query("SELECT * FROM `mod_data_profil` WHERE id='1'");
$data = $koneksi_db->sql_fetchrow($res);

if (!$data) {
    $tengah .= '<div class="container" style="padding:100px 0; text-align:center;">
        <h2 style="color:#306238; font-weight:800;">Data Profil Belum Diatur</h2>
        <p>Silakan atur profil di halaman admin.</p>
    </div>';
} else {
    // --- Tampilan Halaman Profil Mewah ---
    
    // 1. Hero Area
    $tengah .= '
    <div class="profil-hero" style="background: linear-gradient(135deg, #1e4d27 0%, #306238 100%); padding: 100px 0 60px; color: white; position: relative; overflow: hidden;">
        <div style="position: absolute; inset: 0; opacity: 0.1; background-image: radial-gradient(#fff 1px, transparent 1px); background-size: 30px 30px;"></div>
        <div class="container" style="position: relative; z-index: 2; text-align: center;">
            <div style="text-transform: uppercase; letter-spacing: 4px; font-size: 11px; font-weight: 700; color: #9EBB97; margin-bottom: 15px;">Tentang Kami</div>
            <h1 style="font-size: clamp(2rem, 5vw, 3.5rem); font-weight: 900; margin: 0; color: #fff; letter-spacing: -2px; line-height: 1.1;">'.htmlspecialchars($data['nama']).'</h1>
            '.($data['slogan'] ? '<p style="font-size: 18px; margin-top: 20px; opacity: 0.8; font-weight: 500;">'.htmlspecialchars($data['slogan']).'</p>' : '').'
        </div>
    </div>';

    // 2. Konten Utama
    $tengah .= '
    <div style="background: #f8faf9; padding: 0 0 100px;">
        <div class="container" style="margin-top: -60px; position: relative; z-index: 10;">
            <div class="row">
                <div class="col-md-9 mx-auto">
                    <div style="background: #fff; border-radius: 30px; box-shadow: 0 40px 100px rgba(0,0,0,0.08); overflow: hidden; border: 1px solid rgba(0,0,0,0.05);">';
    
    // Video Profil di atas jika ada
    $vid_res = $koneksi_db->sql_query("SELECT * FROM `mod_data_video` ORDER BY id DESC LIMIT 1");
    $vid = $koneksi_db->sql_fetchrow($vid_res);
    if ($vid && !empty($vid['video'])) {
        $tengah .= '
        <div style="width: 100%; aspect-ratio: 16/9; background: #000;">
            <iframe width="100%" height="100%" src="https://www.youtube.com/embed/'.$vid['video'].'" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        </div>';
    }

    $tengah .= '
                        <div style="padding: 60px 80px;">
                            <div class="profil-body" style="line-height: 2; color: #444; font-size: 18px; font-family: \'Inter\', sans-serif;">
                                <style>
                                    .profil-body p { margin-bottom: 30px; text-align: justify; }
                                    .profil-body h2 { color: #1e4d27; font-weight: 800; margin-top: 40px; margin-bottom: 20px; }
                                </style>
                                '.nl2br($data['sambutan']).'
                            </div>
                            
                            <div style="margin-top: 50px; padding-top: 30px; border-top: 1px solid #eee; text-align: center;">
                                <a href="index.php" class="btn-back" style="color: #306238; font-weight: 700; text-decoration: none; font-size: 15px; display: inline-flex; align-items: center; gap: 8px;">
                                    <i class="fa fa-arrow-left"></i> Kembali ke Beranda
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>';
}

echo $tengah;
?>
